package cuploader.frames;

import cuploader.Data;
import cuploader.Data.Elem;
import cuploader.PFile;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.filechooser.FileFilter;


public class Main extends javax.swing.JFrame {
    Data data;
    File directory = null;
    
    WindowListener exit = new WindowAdapter() {
        @Override
        public void windowClosing(WindowEvent evt) {
            ConfirmClose();
        }
    };
     
    public Main() {
        super("Uploader");
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        initComponents();
        setLocationRelativeTo(null);
        
        //addWindowListener(exit);
        Image im = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/cuploader/resources/color-swatch-commons.png"));
        
        setIconImage(im);
        
        data = new Data(lFileUpload, lFileEdit, lUserInfo, FileContainer, mLogin);
        
        FileContainerScroll.getVerticalScrollBar().setUnitIncrement(16);
        mEdit.setEnabled(false);
        mFileUploadSelect.setEnabled(false);
        mUpload.setEnabled(false);
        
//        double dou = -8.9;
//        System.out.print((int)(dou));
    }
      
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem2 = new javax.swing.JMenuItem();
        UserInfo = new javax.swing.JPanel();
        lUserInfo = new javax.swing.JLabel();
        FileContainerScroll = new javax.swing.JScrollPane();
        FileContainer = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        lFileUpload = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        lFileEdit = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        mMenu = new javax.swing.JMenuBar();
        mFile = new javax.swing.JMenu();
        mLoadDirectory = new javax.swing.JMenuItem();
        jSeparator5 = new javax.swing.JPopupMenu.Separator();
        mLoadSession = new javax.swing.JMenuItem();
        mSaveSession = new javax.swing.JMenuItem();
        mCleanSession = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        mLogin = new javax.swing.JMenuItem();
        mUpload = new javax.swing.JMenuItem();
        jSeparator4 = new javax.swing.JPopupMenu.Separator();
        mFileUploadSelect = new javax.swing.JMenu();
        mFileUploadSelectAll = new javax.swing.JMenuItem();
        mFileUploadSelectInv = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        mEnd = new javax.swing.JMenuItem();
        mEdit = new javax.swing.JMenu();
        mFileSelectAll = new javax.swing.JMenuItem();
        mFileSelectInv = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        mFileSelectedToUpload = new javax.swing.JMenuItem();
        mFileEditSelected = new javax.swing.JMenuItem();
        mTools = new javax.swing.JMenu();
        mOptions = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();
        mHelp = new javax.swing.JMenu();
        mAbout = new javax.swing.JMenuItem();

        jMenuItem2.setText("jMenuItem2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1000, 600));

        UserInfo.setBorder(javax.swing.BorderFactory.createTitledBorder("Status"));

        lUserInfo.setForeground(new java.awt.Color(102, 102, 102));
        lUserInfo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/user.png"))); // NOI18N
        lUserInfo.setText("Niezalogowany");

        javax.swing.GroupLayout UserInfoLayout = new javax.swing.GroupLayout(UserInfo);
        UserInfo.setLayout(UserInfoLayout);
        UserInfoLayout.setHorizontalGroup(
            UserInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UserInfoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lUserInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        UserInfoLayout.setVerticalGroup(
            UserInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(UserInfoLayout.createSequentialGroup()
                .addComponent(lUserInfo)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        FileContainerScroll.setBorder(javax.swing.BorderFactory.createCompoundBorder());

        FileContainer.setAutoscrolls(true);

        jLabel3.setText("  Aby wczytać grafiki wybierz folder (Ctrl + Spacja)");
        jLabel3.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        javax.swing.GroupLayout FileContainerLayout = new javax.swing.GroupLayout(FileContainer);
        FileContainer.setLayout(FileContainerLayout);
        FileContainerLayout.setHorizontalGroup(
            FileContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FileContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 577, Short.MAX_VALUE)
                .addContainerGap())
        );
        FileContainerLayout.setVerticalGroup(
            FileContainerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(FileContainerLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(404, Short.MAX_VALUE))
        );

        FileContainerScroll.setViewportView(FileContainer);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Upload"));

        lFileUpload.setText("0 / 0");

        jLabel1.setText("Plików do przesłania:");

        lFileEdit.setText("0");

        jLabel2.setText("Do edycji:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lFileUpload, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
                    .addComponent(lFileEdit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(lFileUpload))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lFileEdit)
                    .addComponent(jLabel2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Opis"));

        jLabel4.setText("<html><body>1. wczytaj zdjęcia (Ctrl + Spacja)<br>2. uzupełnij opisy i zaznacz do wysłania<br>3. zaloguj się<br>4. przesyłaj</body></html>>");
        jLabel4.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jLabel4.setVerticalTextPosition(javax.swing.SwingConstants.TOP);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(219, Short.MAX_VALUE))
        );

        mFile.setText("Plik");

        mLoadDirectory.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_SPACE, java.awt.event.InputEvent.CTRL_MASK));
        mLoadDirectory.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/folder-open.png"))); // NOI18N
        mLoadDirectory.setText("Wczytaj folder");
        mLoadDirectory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mLoadDirectoryActionPerformed(evt);
            }
        });
        mFile.add(mLoadDirectory);
        mFile.add(jSeparator5);

        mLoadSession.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_MASK));
        mLoadSession.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/blue-folder-horizontal-open.png"))); // NOI18N
        mLoadSession.setText("Otwórz sesję");
        mLoadSession.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mLoadSessionActionPerformed(evt);
            }
        });
        mFile.add(mLoadSession);

        mSaveSession.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        mSaveSession.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/disk-black.png"))); // NOI18N
        mSaveSession.setText("Zapisz sesję");
        mSaveSession.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mSaveSessionActionPerformed(evt);
            }
        });
        mFile.add(mSaveSession);

        mCleanSession.setText("Wyczyść sesję");
        mCleanSession.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mCleanSessionActionPerformed(evt);
            }
        });
        mFile.add(mCleanSession);
        mFile.add(jSeparator3);

        mLogin.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.CTRL_MASK));
        mLogin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/users.png"))); // NOI18N
        mLogin.setText("Zaloguj");
        mLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mLoginActionPerformed(evt);
            }
        });
        mFile.add(mLogin);

        mUpload.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_U, java.awt.event.InputEvent.CTRL_MASK));
        mUpload.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/drive-upload.png"))); // NOI18N
        mUpload.setText("Prześlij zdjęcia");
        mUpload.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mUploadActionPerformed(evt);
            }
        });
        mFile.add(mUpload);
        mFile.add(jSeparator4);

        mFileUploadSelect.setText("Pliki do wysłania...");

        mFileUploadSelectAll.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        mFileUploadSelectAll.setText("Zaznacz wszystkie");
        mFileUploadSelectAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mFileUploadSelectAllActionPerformed(evt);
            }
        });
        mFileUploadSelect.add(mFileUploadSelectAll);

        mFileUploadSelectInv.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I, java.awt.event.InputEvent.SHIFT_MASK | java.awt.event.InputEvent.CTRL_MASK));
        mFileUploadSelectInv.setText("Odwróć zaznaczenie");
        mFileUploadSelectInv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mFileUploadSelectInvActionPerformed(evt);
            }
        });
        mFileUploadSelect.add(mFileUploadSelectInv);

        mFile.add(mFileUploadSelect);
        mFile.add(jSeparator1);

        mEnd.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, java.awt.event.InputEvent.ALT_MASK));
        mEnd.setText("Koniec");
        mEnd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mEndActionPerformed(evt);
            }
        });
        mFile.add(mEnd);

        mMenu.add(mFile);

        mEdit.setText("Edycja");

        mFileSelectAll.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        mFileSelectAll.setText("Zaznacz wszystkie pliki");
        mFileSelectAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mFileSelectAllActionPerformed(evt);
            }
        });
        mEdit.add(mFileSelectAll);

        mFileSelectInv.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_I, java.awt.event.InputEvent.CTRL_MASK));
        mFileSelectInv.setText("Odwróć zaznaczenie");
        mFileSelectInv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mFileSelectInvActionPerformed(evt);
            }
        });
        mEdit.add(mFileSelectInv);
        mEdit.add(jSeparator2);

        mFileSelectedToUpload.setText("Dodaj zaznaczone pliki do wysłania");
        mFileSelectedToUpload.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mFileSelectedToUploadActionPerformed(evt);
            }
        });
        mEdit.add(mFileSelectedToUpload);

        mFileEditSelected.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_MASK));
        mFileEditSelected.setText("Edytuj opis zaznaczonych plików");
        mFileEditSelected.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mFileEditSelectedActionPerformed(evt);
            }
        });
        mEdit.add(mFileEditSelected);

        mMenu.add(mEdit);

        mTools.setText("Narzędzia");

        mOptions.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F12, 0));
        mOptions.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/screwdriver.png"))); // NOI18N
        mOptions.setText("Opcje plików i serwera");
        mOptions.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mOptionsActionPerformed(evt);
            }
        });
        mTools.add(mOptions);

        jMenuItem1.setText("Opcje programu");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        mTools.add(jMenuItem1);

        mMenu.add(mTools);

        mHelp.setText("Pomoc");

        mAbout.setText("O programie");
        mAbout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mAboutActionPerformed(evt);
            }
        });
        mHelp.add(mAbout);

        mMenu.add(mHelp);

        setJMenuBar(mMenu);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(FileContainerScroll, javax.swing.GroupLayout.DEFAULT_SIZE, 597, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(UserInfo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(UserInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(FileContainerScroll))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
   
    private void mLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mLoginActionPerformed
        FLogin fLogin = new FLogin(data);
    }//GEN-LAST:event_mLoginActionPerformed

    private void mEndActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mEndActionPerformed
        ConfirmClose();
    }//GEN-LAST:event_mEndActionPerformed

    private void mUploadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mUploadActionPerformed
        if(data.filesUpload==0)
            JOptionPane.showMessageDialog(rootPane, "Zaznacz pliki do wysłania");
        else {
            FUpload fUpload = new FUpload(data);
        }

    }//GEN-LAST:event_mUploadActionPerformed

    private void mFileUploadSelectAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mFileUploadSelectAllActionPerformed
        for(PFile i : data.getFiles())
            i.SelectToUpload(true);
    }//GEN-LAST:event_mFileUploadSelectAllActionPerformed

    private void mFileUploadSelectInvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mFileUploadSelectInvActionPerformed
        for(PFile i : data.getFiles())
            i.SelectToUpload(!i.toUpload);
    }//GEN-LAST:event_mFileUploadSelectInvActionPerformed

    private void mFileEditSelectedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mFileEditSelectedActionPerformed
        if(data.getFilesEdit()>0) {
            FFileEdit fFileEdit = new FFileEdit(data);
        } else
            JOptionPane.showMessageDialog(rootPane, "Zaznacz pliki do edycji");
    }//GEN-LAST:event_mFileEditSelectedActionPerformed

    private void mLoadDirectoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mLoadDirectoryActionPerformed
        JFileChooser ch = new JFileChooser();
            ch.setCurrentDirectory(directory);
            ch.setDialogTitle("Wczytaj pliki...");
            ch.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            ch.setAcceptAllFileFilterUsed(false);

            if (ch.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                LoadDirectory(ch.getSelectedFile().listFiles());
                directory = ch.getCurrentDirectory();
            }
    }//GEN-LAST:event_mLoadDirectoryActionPerformed

    private void mOptionsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mOptionsActionPerformed
        FFileSettings sf = new FFileSettings(data);
        sf.setDefaultCloseOperation(FLogin.DISPOSE_ON_CLOSE);
    }//GEN-LAST:event_mOptionsActionPerformed

    private void mFileSelectAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mFileSelectAllActionPerformed
        for(PFile i : data.getFiles())
            i.SelectToEdit(true);
    }//GEN-LAST:event_mFileSelectAllActionPerformed

    private void mFileSelectInvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mFileSelectInvActionPerformed
        for(PFile i : data.getFiles())
            i.SelectToEdit(!i.toEdit);
    }//GEN-LAST:event_mFileSelectInvActionPerformed

    private void mFileSelectedToUploadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mFileSelectedToUploadActionPerformed
        for(PFile i : data.getFiles()) {
            if(i.toEdit) {
                i.SelectToUpload(true);
                //i.SelectToEdit(false);
            }
        }
    }//GEN-LAST:event_mFileSelectedToUploadActionPerformed

    private void mSaveSessionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mSaveSessionActionPerformed
        JFileChooser ch = new JFileChooser();
            ch.setCurrentDirectory(directory);
            ch.setDialogTitle("Zapisz sesję");
            ch.setAcceptAllFileFilterUsed(false);
            ch.addChoosableFileFilter(new TextFilter());
            ch.setSelectedFile(new File(directory, "session"));
            
            if (ch.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
                File file = new File(ch.getSelectedFile().getAbsolutePath());
                if(!file.exists()) {
                    try {
                        file = new File(file.getAbsoluteFile()+".txt");
                        file.createNewFile();
                        boolean result = SaveSession(file);
                        if(result) JOptionPane.showMessageDialog(rootPane, "Zapis zakończony powodzeniem");
                    } catch (IOException ex) {
                        JOptionPane.showMessageDialog(rootPane, "Błąd: " + ex.toString());
                        Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else {
                    int dialog = JOptionPane.showConfirmDialog(rootPane, "Plik istnieje. Nadpisać?");
                    if(dialog==0) {
                        boolean result = SaveSession(file);
                        if(result) JOptionPane.showMessageDialog(rootPane, "Zapis zakończony powodzeniem");
                    }
                }
            }
    }//GEN-LAST:event_mSaveSessionActionPerformed

    private void mLoadSessionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mLoadSessionActionPerformed
        JFileChooser ch = new JFileChooser();
            ch.setCurrentDirectory(directory);
            ch.setDialogTitle("Wczytaj sesję");
            ch.setAcceptAllFileFilterUsed(false);
            ch.addChoosableFileFilter(new TextFilter());

            if (ch.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
                LoadSession(ch.getSelectedFile());
                //JOptionPane.showMessageDialog(rootPane, "Sesja wczytana");
            }
                
    }//GEN-LAST:event_mLoadSessionActionPerformed

    private void mAboutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mAboutActionPerformed
        FAbout fAbout = new FAbout(data);
    }//GEN-LAST:event_mAboutActionPerformed

    private void mCleanSessionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mCleanSessionActionPerformed
        if(JOptionPane.showConfirmDialog(rootPane, "Jesteś pewien?")==0)
            data.getFiles().clear();
            FileContainer.removeAll();
            FileContainer.repaint();
            
            mEdit.setEnabled(false);
            mFileUploadSelect.setEnabled(false);
            mUpload.setEnabled(false);
    }//GEN-LAST:event_mCleanSessionActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        FSettings fSettings = new FSettings();
    }//GEN-LAST:event_jMenuItem1ActionPerformed
    
    public boolean SaveSession(File file) {
        String string = null;
        if(data.extratext!=null) 
            string = data.extratext.replaceAll("\n", "[nl]");

        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");

        BufferedWriter out = null;
        try {
            out = new BufferedWriter(new FileWriter(file));

            out.write("*** cUploader Session File ***\r\ngenerated " + dateFormat.format(calendar.getTime()) + "\r\n\r\n");
            out.write("server\t"+data.server+
                    "\r\nuser\t"+data.username+
                    "\r\nauthor\t"+data.author+
                    "\r\nlicense\t"+data.license+
                    "\r\ncustomlicense\t"+data.licensesTemplates.get(data.licensesTemplates.size()-1)+
                    "\r\nattrib\t"+data.attrib+
                    "\r\nextratext\t"+string+
                    "\r\n\r\n"+data.getFiles().size()+
                    "\r\n");

            for(PFile f : data.getFiles()) {
                out.write(f.file.getAbsolutePath()+"\t");      //path
                out.write(Boolean.toString(f.toUpload)+"\t");     //to upload (bool)
                out.write(Boolean.toString(f.toEdit)+"\t");       //to edit (bool)

                //name
                string = f.getValue(Elem.NAME).equals("") ? "null" : f.getValue(Elem.NAME);
                out.write(string+"\t");
                //desc
                string = f.getValue(Elem.DESC).equals("") ? "null" : f.getValue(Elem.DESC).replaceAll("\n", "[nl]");
                out.write(string+"\t");
                //date
                string = f.getValue(Elem.DATE).equals("") ? "null" : f.getValue(Elem.DATE);
                out.write(string+"\t");
                //cats
                string = f.getValue(Elem.CATS).equals("") ? "null" : f.getValue(Elem.CATS);
                out.write(string+"\t");
                //coor
                string = f.getValue(Elem.COOR).equals("") ? "null" : f.coor.getDecimal();//f.getValue(Elem.COOR);
                out.write(string+"\r\n");
            }
        } catch (FileNotFoundException ex) {
            return false;
        } catch (IOException ex) {
            return false;
        } finally {
            //Close the BufferedWriter
            try {
                if (out != null) {
                    out.flush();
                    out.close();
                }
            } catch (IOException ex) {
                return false;
            }
        }
        return true;
    }
    
    public void LoadSession(File file) {
        try {
            //try (BufferedReader in = new BufferedReader(new FileReader(file))) {
            BufferedReader in = new BufferedReader(new FileReader(file));                    
                //infotrash
                for(int i=0;i<3;++i) in.readLine();
                
                //settings
                String[] values;
                String string;
                while(!"".equals(string=in.readLine())) {
                    values = string.split("\t");
                    if(!"null".equals(values[1])) {
                        if("server".equals(values[0])) 
                            data.server=values[1];
                        if("user".equals(values[0])) 
                            data.username=values[1];
                        if("author".equals(values[0])) 
                            data.author=values[1];
                        if("license".equals(values[0])) 
                            data.license=Integer.parseInt(values[1]);
                        if("customlicense".equals(values[0])) 
                            data.licensesTemplates.set(data.licensesTemplates.size()-1, values[1]);
                        if("attrib".equals(values[0])) 
                            data.attrib=values[1];
                        if("extratext".equals(values[0]))
                            data.extratext = values[1].replace("[nl]", "\n");
                    }
                }
                
                //'n' of images
                final int n = Integer.parseInt(in.readLine());
                data.loadSessionData = new String[n][8];
                
                //read images
                for(int i=0;;++i) {
                    string = in.readLine();
                    if(string!=null)
                        data.loadSessionData[i] = string.split("\t");
                    else break;
                }
                
                final File[] images = new File[n];
                for(int i=0;i<n;++i)
                    images[i] = new File(data.loadSessionData[i][0]);
                
                data.isLoadSession=true;
                LoadDirectory(images);
            //}
        } catch (IOException e) {
            System.out.print("Błąd: " + e.toString());
        }
    }
    
    /**
     * read directory, send list of files to 'loading frame'
     */
    public boolean LoadDirectory(File[] files) {
        
        if(files.length>0) {
            FileContainer.setLayout(new BoxLayout(FileContainer, BoxLayout.PAGE_AXIS));
            
            ArrayList<File> images = new ArrayList<File>();
            
            for(File file : files) { 
                if(file.isFile()) {
                    String fName = file.getName();
                    String fExt = fName.substring(fName.lastIndexOf('.')+1).toLowerCase();
                    if(fExt.matches("jpg") || fExt.matches("png"))
                        images.add(file);
                }
            }
            if(images.isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Brak pasujących plików w katalogu");
                return false;
            }
            else {
                FFileLoading fLoadingFiles = new FFileLoading(data, images);
                jLabel3.setVisible(false);
                mEdit.setEnabled(true);
                mFileUploadSelect.setEnabled(true);
                mUpload.setEnabled(true);
                return true;
            }
        } else {
            JOptionPane.showMessageDialog(rootPane, "Brak pasujących plików w katalogu");
            return false;
        }
        
    }
    
    public void ConfirmClose() {
        Object[] options = {"Wyjdź", "Zapisz sesję i wyjdź", "Anuluj"};
        //int n = JOptionPane.showOptionDialog(rootPane, "Czy chcesz wyjść?", "Wyjdź", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
        int n=0;
        switch(n) {
            case 0: {
                System.exit(0);
                break;
            }
            case 1: {
                mSaveSessionActionPerformed(new ActionEvent(mFile, 0, null));
                System.exit(0);
                break;
            }
            case 2 : {
                //JOptionPane.showMessageDialog(rootPane, "Brak pasujących plików w katalogu");
            }
        
            default: break;
        }
        //JOptionPane op = new JOptionPane("Wyjść", JOptionPane.QUESTION_MESSAGE, JOptionPane.YES_NO_OPTION);
    }
    
    public static void main(String args[]) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        final JFrame frame = new Main();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.pack();
            frame.setVisible(true);
        
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            @Override
//            public void run() {
//                new MainFrame().setVisible(true);
//            }
//        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel FileContainer;
    private javax.swing.JScrollPane FileContainerScroll;
    private javax.swing.JPanel UserInfo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JPopupMenu.Separator jSeparator4;
    private javax.swing.JPopupMenu.Separator jSeparator5;
    private javax.swing.JLabel lFileEdit;
    private javax.swing.JLabel lFileUpload;
    private javax.swing.JLabel lUserInfo;
    private javax.swing.JMenuItem mAbout;
    private javax.swing.JMenuItem mCleanSession;
    private javax.swing.JMenu mEdit;
    private javax.swing.JMenuItem mEnd;
    private javax.swing.JMenu mFile;
    private javax.swing.JMenuItem mFileEditSelected;
    private javax.swing.JMenuItem mFileSelectAll;
    private javax.swing.JMenuItem mFileSelectInv;
    private javax.swing.JMenuItem mFileSelectedToUpload;
    private javax.swing.JMenu mFileUploadSelect;
    private javax.swing.JMenuItem mFileUploadSelectAll;
    private javax.swing.JMenuItem mFileUploadSelectInv;
    private javax.swing.JMenu mHelp;
    private javax.swing.JMenuItem mLoadDirectory;
    private javax.swing.JMenuItem mLoadSession;
    private javax.swing.JMenuItem mLogin;
    private javax.swing.JMenuBar mMenu;
    private javax.swing.JMenuItem mOptions;
    private javax.swing.JMenuItem mSaveSession;
    private javax.swing.JMenu mTools;
    private javax.swing.JMenuItem mUpload;
    // End of variables declaration//GEN-END:variables
}
class TextFilter extends FileFilter {

    @Override
    public boolean accept(File f) {
        if (f.isDirectory())
            return true;
        String s = f.getName();
        int i = s.lastIndexOf('.');

        if (i > 0 && i < s.length() - 1)
            if (s.substring(i + 1).toLowerCase().equals("txt"))
                return true;
        return false;
    }

    @Override
    public String getDescription() {
        return "Plik sesji (*.txt)";
    }
}

