package cuploader.frames;

import cuploader.Data;
import javax.swing.DefaultComboBoxModel;

public class FFileSettings extends javax.swing.JFrame {
    private Data data;
    
    public FFileSettings(Data data) {
        super("Ustawienia");
        this.data = data;
        initComponents();
        setResizable(false);
        setVisible(true);
        setLocationRelativeTo(null);
        
        
        String[] lic = new String[data.licenses.size()];
        for(int i=0;i<data.licenses.size();++i)
            lic[i] = data.licenses.get(i);
        cLicense.setModel(new DefaultComboBoxModel(lic));
        
        tAddr.setText(data.server);
        
        //author
        if(!"own".equals(data.author)) {
            rOtherAuthor.setSelected(true);
            tOtherAuthor.setText(data.author);
            tOtherAuthor.setEditable(true);
        }
        //license
        if(data.license == data.licenses.size()-1) {
            cLicense.setSelectedIndex(data.licenses.size()-1);
            tLicense.setEditable(true);
            tLicense.setText(data.licensesTemplates.get(data.licenses.size()-1));
        } else {
            cLicense.setSelectedIndex(data.license);
        }
        //attrib
        tAttrib.setText(data.attrib);
        //extratext
        tExtraText.setText(data.extratext);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        bSave = new javax.swing.JButton();
        bCancel = new javax.swing.JButton();
        pServer = new javax.swing.JPanel();
        lAddr = new javax.swing.JLabel();
        tAddr = new javax.swing.JTextField();
        cServer = new javax.swing.JComboBox();
        pFiles = new javax.swing.JPanel();
        lExtraText = new javax.swing.JLabel();
        tExtraTextScroll = new javax.swing.JScrollPane();
        tExtraText = new javax.swing.JTextArea();
        lLicense = new javax.swing.JLabel();
        cLicense = new javax.swing.JComboBox();
        tLicense = new javax.swing.JTextField();
        lAuthor = new javax.swing.JLabel();
        rOwnWork = new javax.swing.JRadioButton();
        rOtherAuthor = new javax.swing.JRadioButton();
        tOtherAuthor = new javax.swing.JTextField();
        tAttrib = new javax.swing.JTextField();
        lAttrib = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bSave.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/tick.png"))); // NOI18N
        bSave.setText("Zapisz");
        bSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSaveActionPerformed(evt);
            }
        });

        bCancel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/cross.png"))); // NOI18N
        bCancel.setText("Anuluj");
        bCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelActionPerformed(evt);
            }
        });

        pServer.setBorder(javax.swing.BorderFactory.createTitledBorder("Ustawienia serwera"));

        lAddr.setText("Adres");

        tAddr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tAddrActionPerformed(evt);
            }
        });

        cServer.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Wikimedia Commons", "Polska Wikipedia", "Inny..." }));
        cServer.setEnabled(false);

        javax.swing.GroupLayout pServerLayout = new javax.swing.GroupLayout(pServer);
        pServer.setLayout(pServerLayout);
        pServerLayout.setHorizontalGroup(
            pServerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pServerLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lAddr, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cServer, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(tAddr, javax.swing.GroupLayout.PREFERRED_SIZE, 379, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pServerLayout.setVerticalGroup(
            pServerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pServerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(lAddr)
                .addComponent(tAddr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(cServer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pFiles.setBorder(javax.swing.BorderFactory.createTitledBorder("Ustawienia plików"));

        lExtraText.setText("Tekst pod licencją");

        tExtraText.setColumns(20);
        tExtraText.setFont(new java.awt.Font("Courier New", 0, 12)); // NOI18N
        tExtraText.setRows(5);
        tExtraTextScroll.setViewportView(tExtraText);

        lLicense.setText("Licencja");

        cLicense.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cLicenseActionPerformed(evt);
            }
        });

        tLicense.setEnabled(false);

        lAuthor.setText("Autor");

        buttonGroup1.add(rOwnWork);
        rOwnWork.setSelected(true);
        rOwnWork.setText(" Praca własna");
        rOwnWork.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rOwnWorkActionPerformed(evt);
            }
        });

        buttonGroup1.add(rOtherAuthor);
        rOtherAuthor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rOtherAuthorActionPerformed(evt);
            }
        });

        tOtherAuthor.setEnabled(false);

        tAttrib.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tAttribActionPerformed(evt);
            }
        });

        lAttrib.setText("Atrybucja");

        javax.swing.GroupLayout pFilesLayout = new javax.swing.GroupLayout(pFiles);
        pFiles.setLayout(pFilesLayout);
        pFilesLayout.setHorizontalGroup(
            pFilesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pFilesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pFilesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lLicense, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lAuthor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lAttrib, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pFilesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pFilesLayout.createSequentialGroup()
                        .addGroup(pFilesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(pFilesLayout.createSequentialGroup()
                                .addComponent(rOtherAuthor)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tOtherAuthor))
                            .addComponent(tLicense)
                            .addComponent(cLicense, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(rOwnWork, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE))
                        .addGap(21, 21, 21)
                        .addComponent(lExtraText, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(tExtraTextScroll))
                    .addGroup(pFilesLayout.createSequentialGroup()
                        .addComponent(tAttrib, javax.swing.GroupLayout.PREFERRED_SIZE, 598, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 8, Short.MAX_VALUE)))
                .addContainerGap())
        );
        pFilesLayout.setVerticalGroup(
            pFilesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pFilesLayout.createSequentialGroup()
                .addGroup(pFilesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(tExtraTextScroll)
                    .addGroup(pFilesLayout.createSequentialGroup()
                        .addGroup(pFilesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lAuthor)
                            .addComponent(rOwnWork)
                            .addComponent(lExtraText))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pFilesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(rOtherAuthor)
                            .addComponent(tOtherAuthor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(pFilesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lLicense)
                            .addComponent(cLicense, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tLicense, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(pFilesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tAttrib)
                    .addComponent(lAttrib, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(pFiles, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pServer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(bCancel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bSave)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pServer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pFiles, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bSave)
                    .addComponent(bCancel))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSaveActionPerformed
        data.server = tAddr.getText();
        
        //author
        if(rOtherAuthor.isSelected() && !"".equals(tOtherAuthor.getText())) data.author = tOtherAuthor.getText();
            else data.author = "own";
        //license
        if(cLicense.getSelectedIndex() == data.licenses.size()-1) {
            if(!"".equals(tLicense.getText())) {
                data.licensesTemplates.set(data.licenses.size()-1, tLicense.getText());
                data.license = data.licenses.size()-1;
            }
        } else 
            data.license = cLicense.getSelectedIndex();
        //attrib
        if(tAttrib.getText() == null ? data.attrib != null : !tAttrib.getText().equals(data.attrib)) 
            data.attrib = tAttrib.getText();
        //extra text
        if(data.extratext == null ? tExtraText.getText() != null : !data.extratext.equals(tExtraText.getText())) 
            data.extratext = tExtraText.getText();
        
        setVisible(false);
    }//GEN-LAST:event_bSaveActionPerformed

    private void bCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelActionPerformed
        setVisible(false);
    }//GEN-LAST:event_bCancelActionPerformed

    private void rOtherAuthorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rOtherAuthorActionPerformed
        tOtherAuthor.setEnabled(true);
    }//GEN-LAST:event_rOtherAuthorActionPerformed

    private void rOwnWorkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rOwnWorkActionPerformed
        tOtherAuthor.setEnabled(false);
    }//GEN-LAST:event_rOwnWorkActionPerformed

    private void cLicenseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cLicenseActionPerformed
        if(cLicense.getSelectedIndex()==(data.licenses.size()-1)) tLicense.setEnabled(true);
        else tLicense.setEnabled(false);
    }//GEN-LAST:event_cLicenseActionPerformed

    private void tAttribActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tAttribActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tAttribActionPerformed

    private void tAddrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tAddrActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tAddrActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bCancel;
    private javax.swing.JButton bSave;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox cLicense;
    private javax.swing.JComboBox cServer;
    private javax.swing.JLabel lAddr;
    private javax.swing.JLabel lAttrib;
    private javax.swing.JLabel lAuthor;
    private javax.swing.JLabel lExtraText;
    private javax.swing.JLabel lLicense;
    private javax.swing.JPanel pFiles;
    private javax.swing.JPanel pServer;
    private javax.swing.JRadioButton rOtherAuthor;
    private javax.swing.JRadioButton rOwnWork;
    private javax.swing.JTextField tAddr;
    private javax.swing.JTextField tAttrib;
    private javax.swing.JTextArea tExtraText;
    private javax.swing.JScrollPane tExtraTextScroll;
    private javax.swing.JTextField tLicense;
    private javax.swing.JTextField tOtherAuthor;
    // End of variables declaration//GEN-END:variables
}
