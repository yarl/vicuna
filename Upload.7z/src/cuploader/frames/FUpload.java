package cuploader.frames;

import cuploader.Data;
import cuploader.Data.Elem;
import cuploader.PFile;
import java.io.IOException;
import java.util.ArrayList;
import javax.security.auth.login.CredentialException;
import javax.security.auth.login.CredentialNotFoundException;
import javax.security.auth.login.LoginException;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class FUpload extends javax.swing.JFrame {
    Data data;
    
    private volatile boolean stopRq = false;
    boolean locNames = true;
            
    public FUpload(Data data) {
        super("Wysyłanie");
        this.data = data;
        
        initComponents();
        setResizable(false);
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(FLogin.DISPOSE_ON_CLOSE); 
        
        startCheck();
    }
    
    private void startCheck() {
        Runnable run = new Runnable() {
            @Override
            public void run() {
                
                jLabel1.setIcon(new ImageIcon(getClass().getResource("/cuploader/resources/ui-progress-bar-indeterminate.gif")));
                int i = 0;
                for(i=0;i<data.getFiles().size();++i) {
                    if(data.getFiles().get(i).getValue(Elem.NAME).matches("(DSCF).*||(IMG).*"))
                        locNames = false;
                }
                
                if(!locNames) {
                    jLabel1.setIcon(new ImageIcon(getClass().getResource("/cuploader/resources/cross.png")));
                    tResults.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/exclamation.png")));
                    tResults.setText("Pliki nie powinny mieć nazw IMG lub DSCF");
                }
                else {
                    jLabel1.setIcon(new ImageIcon(getClass().getResource("/cuploader/resources/tick.png")));
                    jLabel2.setIcon(new ImageIcon(getClass().getResource("/cuploader/resources/ui-progress-bar-indeterminate.gif")));
                    ArrayList<String> cont = new ArrayList<String>();
                    for(i=0;i<data.getFiles().size();++i) {
                        if(data.getFiles().get(i).toUpload) {
                            cont.add(data.getFiles().get(i).getValue(Elem.NAME)+"."+data.getFiles().get(i).getValue(Elem.EXT));
                            System.out.println("Dodaję: " + i + " / " + data.getFiles().get(i).getValue(Elem.NAME)+"."+data.getFiles().get(i).getValue(Elem.EXT));
                        }
                    }
                    String dupes = "";
                    try {
                        for(i=0;i<cont.size();++i) {
                            boolean info = data.wiki.isPageExist(cont.get(i));
                            if(info) dupes += cont.get(i)+", ";
                        }
                    } catch (IOException ex) {}
                    
                    if(!dupes.equals("")) {
                        jLabel2.setIcon(new ImageIcon(getClass().getResource("/cuploader/resources/cross.png")));
                        tResults.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/exclamation.png")));
                        tResults.setText("Zajęte: " + dupes);
                    } else {                     
                        jLabel2.setIcon(new ImageIcon(getClass().getResource("/cuploader/resources/tick.png")));
                        tResults.setText("Wszystko OK");
                        bUpload.setEnabled(true);
                    }
                }
                stopCheck();
            }
        };
        
        //start = System.nanoTime();  
        Thread t = new Thread(run);
        t.start();
    }
    
    private void stopCheck() {
        stopRq = true;
        //long end = System.nanoTime()-start;
        //System.out.print("Trwało: " + end/1000.0/1000.0/1000.0);
        //setVisible(false);
    }
    
    private void startUpload() {
        stopRq = false;
        Runnable run = new Runnable() {
            @Override
            public void run() {
                for(PFile i : data.getFiles()) { 
                    if(i.toUpload) {
                        String desc = "\nDesc: " + i.getValue(Elem.DESC) + "\nDate: " + i.getValue(Elem.DATE);

                        try {
                            String name = i.getValue(Elem.NAME)+"."+i.getValue(Elem.EXT);
                            data.wiki.upload(i.file, name, desc, "File upload test");
                            i.setAsUploaded();
                        } catch (CredentialNotFoundException ex) {
                            JOptionPane.showMessageDialog(rootPane, "Z tego konta nie można przesyłać zdjęć");
                            break;
                        } catch (CredentialException ex) {
                            i.setAsFailed("strona zablokowana do edycji");
                            //JOptionPane.showMessageDialog(rootPane, "Strona zablokowana");
                        } catch (LoginException ex) {
                            i.setAsFailed(ex.getLocalizedMessage());
                            //JOptionPane.showMessageDialog(rootPane, "Wystąpił błąd: " + ex.toString());
                            //Logger.getLogger(F_Main.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (IOException ex) {
                            i.setAsFailed(ex.getLocalizedMessage());
                            //JOptionPane.showMessageDialog(rootPane, "Wystąpił błąd: " + ex.toString());
                        }
                    }
                }
                stopUpload();
            }
        };
        
        //start = System.nanoTime();  
        Thread t = new Thread(run);
        
        if(data.isLogged)
            t.start();
        else {
            FLogin fLogin = new FLogin(data);
        }
        
    }
    
    private void stopUpload() {
        stopRq = true;
        setVisible(false);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bUpload = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        tResults = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bUpload.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/tick.png"))); // NOI18N
        bUpload.setText("Wyślij");
        bUpload.setEnabled(false);
        bUpload.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bUploadActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/-spacer.png"))); // NOI18N
        jLabel1.setText("Sprawdzanie nazw...");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/-spacer.png"))); // NOI18N
        jLabel2.setText("Sprawdzanie nazw na serwerze...");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(tResults, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(64, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tResults, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/arrow-circle-135-left.png"))); // NOI18N
        jButton1.setText("Popraw");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bUpload)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(bUpload, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bUploadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bUploadActionPerformed
        startUpload();
    }//GEN-LAST:event_bUploadActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bUpload;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel tResults;
    // End of variables declaration//GEN-END:variables
}
