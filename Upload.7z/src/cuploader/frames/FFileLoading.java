package cuploader.frames;

import cuploader.Data;
import cuploader.PFile;
import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;

public final class FFileLoading extends javax.swing.JFrame {
    private ArrayList<File> files = null;
    private Data data;
    //long start;
    
    private volatile boolean stopRq = false;
    
    public FFileLoading(Data data, ArrayList<File> files) {
        super("Wczytywanie");
        this.data = data; 
        this.files = files;
        
        initComponents();
        setResizable(false);
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(FLogin.DISPOSE_ON_CLOSE);
        getRootPane().setDefaultButton(bHide);  
        bHide.requestFocus();  
        startRead();
        
    }
            
    private void startRead() {
        Progress.setMinimum(0);
        Progress.setMaximum(files.size());
        
        Runnable run = new Runnable() {
            @Override
            public void run() {
                Progress.setIndeterminate(false);
                DecimalFormat df = new DecimalFormat("#.##");
                
                int i = 0;
                for(File file : files) {
                    if(!stopRq) {
                        /*try {
                            Metadata metadata = ImageMetadataReader.readMetadata(file);
                            for (Directory directory : metadata.getDirectories()) {
                                for (Tag tag : directory.getTags()) {
                                    System.out.println(tag);
                                }
                            }
                        } catch (ImageProcessingException ex) {
                            Logger.getLogger(FFileLoading.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (IOException ex) {
                            Logger.getLogger(FFileLoading.class.getName()).log(Level.SEVERE, null, ex);
                        }*/

                        lName.setText("Wczytuję " + (int)(i+1) + " z " + files.size() + ": " + file.getName() + 
                                " (" + df.format(9.5367e-7*file.length()) + " MiB)");
                        
                        PFile panel = new PFile(data, file, data.getFiles().size());
                        data.getFiles().add(panel);
                        data.FileContainer.add(panel);
                        
                        if(data.isLoadSession) {
                            if(data.loadSessionData[i][1].equals("true"))
                                data.getFiles().get(i).SelectToUpload(true);
                            if(data.loadSessionData[i][2].equals("true"))
                                data.getFiles().get(i).SelectToEdit(true);
                        }

                        data.lFileCounter.setText(data.getFilesUpload() + " \\ " + (i+1));
                        Progress.setValue(i+1);
                        ++i;
                    }
                }
                Progress.setIndeterminate(true);
                stopRead();
            }
        };
        
        //start = System.nanoTime();  
        Thread t = new Thread(run);
        t.start();
    }
    
    private void stopRead() {
        data.isLoadSession=false;
        stopRq = true;
        //long end = System.nanoTime()-start;
        //System.out.print("Trwało: " + end/1000.0/1000.0/1000.0);
        setVisible(false);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bStop = new javax.swing.JButton();
        bHide = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        Progress = new javax.swing.JProgressBar();
        lName = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bStop.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/cross.png"))); // NOI18N
        bStop.setText("Przerwij");
        bStop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bStopActionPerformed(evt);
            }
        });

        bHide.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/arrow-circle-135-left.png"))); // NOI18N
        bHide.setText("Ukryj");
        bHide.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bHideActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        Progress.setIndeterminate(true);

        lName.setText("Wczytuję...");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Progress, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lName, javax.swing.GroupLayout.PREFERRED_SIZE, 386, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 14, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Progress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(lName)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(bStop)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(bHide))
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bStop)
                    .addComponent(bHide))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bStopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bStopActionPerformed
        stopRead();
    }//GEN-LAST:event_bStopActionPerformed

    private void bHideActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bHideActionPerformed
        setVisible(false);
    }//GEN-LAST:event_bHideActionPerformed
 
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JProgressBar Progress;
    private javax.swing.JButton bHide;
    private javax.swing.JButton bStop;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lName;
    // End of variables declaration//GEN-END:variables
}
