package cuploader;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import org.wikipedia.Wiki;

public final class Data {
    public enum Elem {
    NAME, EXT, DATE, COOR, DESC, CATS;
    }
    
    public JLabel lFileCounter, lFileEdit, lUserInfo;
    public JPanel FileContainer;
    public JMenuItem mLogin;
    
    //public settings
    public String server = "test.wikipedia.org";
    public String username = null;
    public String author = "own";
    public int license = 0;
    public String attrib = null;
    public String extratext = null;
    public Wiki wiki = new Wiki(server);
    public boolean isLogged = false;
    
    //help vars
    public boolean ctrlPress = false;
    public boolean shiftPress = false;
    public boolean isLoadSession = false;
    public String[][] loadSessionData;
    
    //storage info
    private ArrayList<PFile> files = new ArrayList<PFile>();       //stores all images
    
    public int filesUpload = 0;
    public int filesEdit = 0;
    
    public ArrayList<String> licenses = new ArrayList<String>();
    public ArrayList<String> licensesTemplates = new ArrayList<String>();

    public Data(JLabel lFileCounter, JLabel lFileEdit, JLabel lUserInfo, JPanel FileContainer, JMenuItem mLogin) {
        this.lFileCounter = lFileCounter;
        this.lFileEdit = lFileEdit;
        this.lUserInfo = lUserInfo;
        this.FileContainer = FileContainer;
        this.mLogin = mLogin;

        licenses.add("Creative Commons BY-SA 3.0");             licensesTemplates.add("cc-by-sa 3.0");
        licenses.add("Creative Commons BY 3.0");                licensesTemplates.add("cc-by 3.0");
        licenses.add("GNU Free Documentation License (GFDL)");  licensesTemplates.add("GFDL");
        licenses.add("Inna...");                                licensesTemplates.add(null);
    }

    //get
    public ArrayList<PFile> getFiles() {
        return files;
    }

    public int getFilesUpload() {
        return filesUpload;
    }

    public int getFilesEdit() {
        return filesEdit;
    }

    public int getFirstFileEdit() {
        for (int i = 0; i < files.size(); ++i) {
            if (files.get(i).toEdit) {
                return i;
            }
        }
        return -1;
    }

    public void setdsdFileEdit(int number, boolean bool) {
        if (bool != files.get(number).toEdit) {
            files.get(number).toEdit = bool;
            if (bool) {
                ++filesEdit;
            } else {
                --filesEdit;
            }
            lFileEdit.setText(Integer.toString(number));
        }
    }
    //[shift] and [ctrl] detect
    public KeyListener kl = new KeyListener() {

        @Override
        public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == 16 && !shiftPress) {
                shiftPress = true;
            }
            if (e.getKeyCode() == 17 && !ctrlPress) {
                ctrlPress = true;
            }
            //System.out.print("(pressed): " + e.getKeyCode() + "... ");
        }

        @Override
        public void keyReleased(KeyEvent e) {
            if (e.getKeyCode() == 16) {
                shiftPress = false;
            }
            if (e.getKeyCode() == 17) {
                ctrlPress = false;
            }
            //System.out.print("(rel): " + e.getKeyChar() + "... ");
        }

        @Override
        public void keyTyped(KeyEvent e) {
            //System.out.print(number + " (type): " + e.getKeyChar() + "... ");
        }
    };
    
    public HyperlinkListener hl = new HyperlinkListener() {  
        @Override
        public void hyperlinkUpdate(HyperlinkEvent hle) {  
            if (HyperlinkEvent.EventType.ACTIVATED.equals(hle.getEventType())) {  
                System.out.println(hle.getURL());  
            }  
        }  
    };
}
