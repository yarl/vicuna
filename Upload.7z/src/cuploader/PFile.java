package cuploader;

import com.drew.imaging.ImageMetadataReader;
import com.drew.imaging.ImageProcessingException;
import com.drew.metadata.Directory;
import com.drew.metadata.exif.ExifSubIFDDirectory;
import com.drew.metadata.exif.GpsDirectory;
import cuploader.Data.Elem;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;

public class PFile extends javax.swing.JPanel {
    public boolean toUpload = false;
    public boolean toEdit = false;
    
    //public ;
    public Coordinate coor;
    
    private Data data;
    public File file;
    public int number;
    
    private String ext;

    public PFile(Data data, File file, int number) {  
        this.number = number;
        this.file = file;
        this.data = data;
        
        initComponents();
        TransferFocus.patch(tDesc);
        addKeyListener(data.kl);
        setBorder(BorderFactory.createTitledBorder(file.getName()));
        
        String text;
        if(data.isLoadSession) {
            text = data.loadSessionData[number][3].equals("null") ? "" : data.loadSessionData[number][3];
            tName.setText(text);
            text = data.loadSessionData[number][4].equals("null") ? "" : data.loadSessionData[number][4].replace("[nl]", "\n");
            tDesc.setText(text);
            text = data.loadSessionData[number][5].equals("null") ? "" : data.loadSessionData[number][5];
            tDate.setText(text);
            text = data.loadSessionData[number][6].equals("null") ? "" : data.loadSessionData[number][6];
            tCategories.setText(text);
            
            if(data.loadSessionData[number][7].equals("null"))
                tCoor.setText("");
            else {
                String[] txt = data.loadSessionData[number][7].split(";");
                coor = new Coordinate(txt[0], txt[1]);
                tCoor.setText("<html><body>&nbsp;&nbsp;&nbsp;" + coor.getDMS()[0] + 
                                "<br>&nbsp;&nbsp;&nbsp;" + coor.getDMS()[1] + "</body></html>"); 
                tCoor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/geolocation.png")));
            }
        } else {
            text = file.getName().substring(0, file.getName().lastIndexOf('.'));
            tName.setText(text);
            
            tCategories.setText("");
            tDesc.setText("");

            try {
                Directory directory;
                
                directory = ImageMetadataReader.readMetadata(file).getDirectory(ExifSubIFDDirectory.class);
                if(directory != null && directory.containsTag(ExifSubIFDDirectory.TAG_DATETIME_ORIGINAL)) {
                    Date date = directory.getDate(ExifSubIFDDirectory.TAG_DATETIME_ORIGINAL);
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    tDate.setText(sdf.format(date));
                } else
                    tDate.setText("");
                
                directory = ImageMetadataReader.readMetadata(file).getDirectory(GpsDirectory.class);
                if(directory != null) {  
                    
                    String[] NS = directory.getDescription(GpsDirectory.TAG_GPS_LATITUDE).split(" ");
                        NS[0] = NS[0].substring(0, NS[0].lastIndexOf('°'));
                        NS[1] = NS[1].substring(0, NS[1].lastIndexOf('\''));
                        NS[2] = NS[2].substring(0, NS[2].lastIndexOf('\"'));

                    String[] EW = directory.getDescription(GpsDirectory.TAG_GPS_LONGITUDE).split(" ");
                        EW[0] = EW[0].substring(0, EW[0].lastIndexOf('°'));
                        EW[1] = EW[1].substring(0, EW[1].lastIndexOf('\''));
                        EW[2] = EW[2].substring(0, EW[2].lastIndexOf('\"'));
                    
                    coor = new Coordinate(NS, directory.getDescription(GpsDirectory.TAG_GPS_LATITUDE_REF), 
                                            EW, directory.getDescription(GpsDirectory.TAG_GPS_LONGITUDE_REF));
                    
                    tCoor.setText("<html><body>&nbsp;&nbsp;&nbsp;" + coor.getDMS()[0] + 
                            "<br>&nbsp;&nbsp;&nbsp;" + coor.getDMS()[1] + "</body></html>"); 
                    tCoor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/geolocation.png")));
                } else
                    tCoor.setText("");
            } catch (ImageProcessingException ex) {
                tDate.setText("");
                //Logger.getLogger(FLoadingFiles.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                tDate.setText("");
                //Logger.getLogger(FLoadingFiles.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if(tCoor.getText().equals(""))
            bOpenMap.setVisible(false);
        
        try {
            float ratio = (float)(ImageIO.read(file).getWidth())/(float)(ImageIO.read(file).getHeight());
            int height = 100;
            int width = (int)(100.0*(ratio));
            if(width>150) {
                width = 150;
                height /= ratio;
            }
            BufferedImage img = getScaledInstance(ImageIO.read(file), width, height, RenderingHints.VALUE_INTERPOLATION_BILINEAR, true);
            tThumb.setIcon(new ImageIcon(img));

        } catch (IOException ex) {
            //Logger.getLogger(PFile.class.getName()).log(Level.SEVERE, null, ex);
        }

        //ext icon
        ext = file.getName().substring(file.getName().lastIndexOf('.')+1).toLowerCase();
        if(ext.equals("jpg")) {
            lExt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/document-attribute-j.png")));
            lExt.setToolTipText("Plik JPEG");
        } 
        else if(ext.equals("png")) {
            lExt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/document-attribute-p.png")));
            lExt.setToolTipText("Plik PNG");
        }
        else {
            //lExt.setIcon("");
            //lExt.setToolTipText("");
        }
        
        //size
        DecimalFormat df = new DecimalFormat("#.##");
        tSize.setText(df.format(9.5367e-7*file.length()) + " MiB");
    }
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Panel = new javax.swing.JPanel();
        tThumb = new javax.swing.JLabel();
        tName = new javax.swing.JTextField();
        jScrollPane1 = new cuploader.PDControlScrollPane();
        tDesc = new javax.swing.JTextArea();
        tDate = new javax.swing.JTextField();
        lDate = new javax.swing.JLabel();
        lName = new javax.swing.JLabel();
        lCategories = new javax.swing.JLabel();
        tCategories = new javax.swing.JTextField();
        lDesc = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        lExt = new javax.swing.JLabel();
        tSize = new javax.swing.JLabel();
        tCoor = new javax.swing.JLabel();
        bOpenFile = new javax.swing.JButton();
        bOpenDir = new javax.swing.JButton();
        cUpload = new javax.swing.JCheckBox();
        bOpenMap = new javax.swing.JButton();

        setBorder(javax.swing.BorderFactory.createTitledBorder("<text>"));

        Panel.setName("");
        Panel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PanelMouseClicked(evt);
            }
        });
        Panel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                PanelKeyPressed(evt);
            }
        });

        tThumb.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        tThumb.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/image.png"))); // NOI18N
        tThumb.setFocusable(false);
        tThumb.setMaximumSize(new java.awt.Dimension(150, 100));
        tThumb.setMinimumSize(new java.awt.Dimension(150, 100));
        tThumb.setPreferredSize(new java.awt.Dimension(150, 100));
        tThumb.setVerticalTextPosition(javax.swing.SwingConstants.TOP);

        tName.setText("<name>");
        tName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tNameActionPerformed(evt);
            }
        });
        tName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                tNameFocusLost(evt);
            }
        });

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setNextFocusableComponent(Panel);

        tDesc.setColumns(20);
        tDesc.setFont(new java.awt.Font("Courier New", 0, 12)); // NOI18N
        tDesc.setLineWrap(true);
        tDesc.setRows(3);
        jScrollPane1.setViewportView(tDesc);

        tDate.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tDateFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tDateFocusLost(evt);
            }
        });

        lDate.setText("Data");

        lName.setText("Nazwa");

        lCategories.setText("Kategorie");

        tCategories.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tCategoriesFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tCategoriesFocusLost(evt);
            }
        });

        lDesc.setText("Opis");

        jPanel1.setOpaque(false);

        lExt.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lExt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/document-attribute-j.png"))); // NOI18N
        lExt.setFocusable(false);
        lExt.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);

        tSize.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        tSize.setText("<rozmiar>");

        tCoor.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        tCoor.setPreferredSize(new java.awt.Dimension(34, 20));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(tCoor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lExt, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tSize, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lExt, javax.swing.GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE)
                    .addComponent(tSize, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tCoor, javax.swing.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout PanelLayout = new javax.swing.GroupLayout(Panel);
        Panel.setLayout(PanelLayout);
        PanelLayout.setHorizontalGroup(
            PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(tThumb, javax.swing.GroupLayout.DEFAULT_SIZE, 163, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelLayout.createSequentialGroup()
                        .addGroup(PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(lCategories, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lName, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tCategories))
                    .addGroup(PanelLayout.createSequentialGroup()
                        .addComponent(lDesc, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelLayout.createSequentialGroup()
                        .addComponent(tName)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lDate, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tDate, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 362, Short.MAX_VALUE))
                .addContainerGap())
        );
        PanelLayout.setVerticalGroup(
            PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(PanelLayout.createSequentialGroup()
                        .addGroup(PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lName)
                            .addComponent(lDate))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tDate, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lDesc)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lCategories, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tCategories, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(PanelLayout.createSequentialGroup()
                        .addComponent(tThumb, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        bOpenFile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/magnifier.png"))); // NOI18N
        bOpenFile.setToolTipText("Otwiera plik w domyślnym programie");
        bOpenFile.setFocusable(false);
        bOpenFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bOpenFileActionPerformed(evt);
            }
        });

        bOpenDir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/folder-horizontal-open.png"))); // NOI18N
        bOpenDir.setToolTipText("Otwiera katalog z plikiem");
        bOpenDir.setFocusable(false);
        bOpenDir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bOpenDirActionPerformed(evt);
            }
        });

        cUpload.setBackground(new java.awt.Color(200, 228, 169));
        cUpload.setToolTipText("Zaznacza, czy przesłać plik na serwer");
        cUpload.setFocusable(false);
        cUpload.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cUpload.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        cUpload.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/cross.png"))); // NOI18N
        cUpload.setOpaque(false);
        cUpload.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/tick.png"))); // NOI18N
        cUpload.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cUploadActionPerformed(evt);
            }
        });

        bOpenMap.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cuploader/resources/map.png"))); // NOI18N
        bOpenMap.setToolTipText("Otwiera mapę");
        bOpenMap.setFocusable(false);
        bOpenMap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bOpenMapActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cUpload, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Panel, javax.swing.GroupLayout.DEFAULT_SIZE, 555, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bOpenFile, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bOpenDir, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bOpenMap, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(bOpenFile)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bOpenDir)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bOpenMap, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(Panel, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
            .addComponent(cUpload, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void cUploadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cUploadActionPerformed
        SelectToUpload(cUpload.isSelected());
    }//GEN-LAST:event_cUploadActionPerformed

    private void bOpenDirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bOpenDirActionPerformed
        File f = data.getFiles().get(number).file.getParentFile();
        try {
            Desktop.getDesktop().open(f);
        } catch (IOException e){ }
    }//GEN-LAST:event_bOpenDirActionPerformed

    private void tNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tNameActionPerformed
    }//GEN-LAST:event_tNameActionPerformed

    private void bOpenFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bOpenFileActionPerformed
        File f = data.getFiles().get(number).file.getAbsoluteFile();
        try {
            Desktop.getDesktop().open(f);
        } catch (IOException e){ }
    }//GEN-LAST:event_bOpenFileActionPerformed

    private void tNameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tNameFocusLost
    }//GEN-LAST:event_tNameFocusLost

    private void PanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PanelMouseClicked
        //CTRL
        if(data.ctrlPress)
            SelectToEdit(!data.getFiles().get(number).toEdit/*!data.getFileEdit(number)*/);
        //SHIFT
        else if ((data.ctrlPress && data.shiftPress) || (!data.ctrlPress && data.shiftPress)) {
            int x = data.getFirstFileEdit();
            
            if(x>number) {
                //System.out.println("Od "+number+" do "+x);
                for(int i=0;i<data.getFiles().size();++i) {
                    if(i>=number && i<=x) data.getFiles().get(i).SelectToEdit(true);//data.setFileEdit(i, true);
                    else data.getFiles().get(i).SelectToEdit(false);//data.setFileEdit(i, false);
                }
            } else if(x<number) {
                //System.out.println("Od "+x+" do "+number);
                for(int i=0;i<data.getFiles().size();++i) {
                    if(i<=number && i>=x) data.getFiles().get(i).SelectToEdit(true);//data.setFileEdit(i, true);
                    else data.getFiles().get(i).SelectToEdit(false);//data.setFileEdit(i, false);
                }
            } //else
                //System.out.println("To samo");
        //STANDARD
        } else {
            for(int i=0;i<data.getFiles().size();++i) {
                if(i==number) data.getFiles().get(i).SelectToEdit(true);//data.setFileEdit(i, true);
                else data.getFiles().get(i).SelectToEdit(false);//data.setFileEdit(i, false);
            }
        }
        requestFocusInWindow(true);
    }//GEN-LAST:event_PanelMouseClicked

    private void PanelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PanelKeyPressed
    }//GEN-LAST:event_PanelKeyPressed

    private void tDateFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tDateFocusGained
//        tDate.setBorder(tName.getBorder());
//        tDate.setOpaque(true);
    }//GEN-LAST:event_tDateFocusGained

    private void tDateFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tDateFocusLost
//        tDate.setBorder(null);
//        tDate.setOpaque(false);
    }//GEN-LAST:event_tDateFocusLost

    private void tCategoriesFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tCategoriesFocusGained
//        tCategories.setBorder(tName.getBorder());
//        tCategories.setOpaque(true);
    }//GEN-LAST:event_tCategoriesFocusGained

    private void tCategoriesFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tCategoriesFocusLost
//        tCategories.setBorder(null);
//        tCategories.setOpaque(false);
    }//GEN-LAST:event_tCategoriesFocusLost

    private void bOpenMapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bOpenMapActionPerformed
        try {
            Desktop.getDesktop().browse(new URI("https://maps.google.com/maps?q=" +coor.getNS()+ "+" +coor.getEW()+ "&z=15"));
        } catch (URISyntaxException ex) {
            Logger.getLogger(PFile.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException e){ }
    }//GEN-LAST:event_bOpenMapActionPerformed

    public void changeComponent(Elem component, String text) {
        switch(component) {
            case NAME: {
                tName.setText(text);
                break;
            }
            case DATE: {
                tDate.setText(text);
                break;
            }
            case COOR: {
                tCoor.setText(text);
                tCoor.setForeground(Color.black);
                break;
            }
            case DESC: {
                tDesc.setText(text);
                break;
            }
            case CATS: {
                tCategories.setText(text);
                break;
            }
            default: {
                break;
            }
        }
    }
    
    public String getValue(Elem component) {
        switch(component) {
            case NAME: return tName.getText();
            case EXT: return ext;
            case DATE: return tDate.getText();
            case COOR: return tCoor.getText();
            case DESC: return tDesc.getText();
            case CATS: return tCategories.getText();
            default: return null;
        }
    }
    
    public void setAsUploaded() {
        cUpload.setIcon(new ImageIcon(getClass().getResource("/cuploader/resources/arrow-circle-double.png")));
        cUpload.setEnabled(false);
        cUpload.setOpaque(true);
        cUpload.setBackground(new Color(200,219,237));
    }
    
    public void setAsFailed(String details) {
        cUpload.setIcon(new ImageIcon(getClass().getResource("/cuploader/resources/exclamation.png")));
        cUpload.setEnabled(false);
        cUpload.setOpaque(true);
        cUpload.setBackground(new Color(239,235,127));
        cUpload.setToolTipText("Błąd przesyłania: " + details);
    }
    
    
    public void SelectToUpload(boolean mode) {
        if(mode!=toUpload) {
            toUpload = mode;
            cUpload.setSelected(mode);
            cUpload.setOpaque(mode);

            if(mode) ++data.filesUpload;
            else --data.filesUpload;
            data.lFileCounter.setText(data.filesUpload + " \\ " + data.getFiles().size());
        }
    }
    
    public void SelectToEdit(boolean mode) {
        if(mode!=toEdit) {
            toEdit = mode;
            if(mode) {
                Panel.setBackground(new Color(220,220,220));
                ++data.filesEdit;
            } else {
                Panel.setBackground(new Color(240,240,240));
                --data.filesEdit;
            }
            data.lFileEdit.setText(Integer.toString(data.filesEdit));
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Panel;
    private javax.swing.JButton bOpenDir;
    private javax.swing.JButton bOpenFile;
    private javax.swing.JButton bOpenMap;
    private javax.swing.JCheckBox cUpload;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lCategories;
    private javax.swing.JLabel lDate;
    private javax.swing.JLabel lDesc;
    private javax.swing.JLabel lExt;
    private javax.swing.JLabel lName;
    private javax.swing.JTextField tCategories;
    private javax.swing.JLabel tCoor;
    private javax.swing.JTextField tDate;
    private javax.swing.JTextArea tDesc;
    private javax.swing.JTextField tName;
    private javax.swing.JLabel tSize;
    private javax.swing.JLabel tThumb;
    // End of variables declaration//GEN-END:variables

    /**
     * Convenience method that returns a scaled instance of the
     * provided {@code BufferedImage}.
     *
     * @param img the original image to be scaled
     * @param targetWidth the desired width of the scaled instance,
     *    in pixels
     * @param targetHeight the desired height of the scaled instance,
     *    in pixels
     * @param hint one of the rendering hints that corresponds to
     *    {@code RenderingHints.KEY_INTERPOLATION} (e.g.
     *    {@code RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR},
     *    {@code RenderingHints.VALUE_INTERPOLATION_BILINEAR},
     *    {@code RenderingHints.VALUE_INTERPOLATION_BICUBIC})
     * @param higherQuality if true, this method will use a multi-step
     *    scaling technique that provides higher quality than the usual
     *    one-step technique (only useful in downscaling cases, where
     *    {@code targetWidth} or {@code targetHeight} is
     *    smaller than the original dimensions, and generally only when
     *    the {@code BILINEAR} hint is specified)
     * @return a scaled version of the original {@code BufferedImage}
     */
    private BufferedImage getScaledInstance(BufferedImage img,
                                           int targetWidth,
                                           int targetHeight,
                                           Object hint,
                                           boolean higherQuality)
    {
        int type = (img.getTransparency() == Transparency.OPAQUE) ?
            BufferedImage.TYPE_INT_RGB : BufferedImage.TYPE_INT_ARGB;
        BufferedImage ret = (BufferedImage)img;
        int w, h;
        if (higherQuality) {
            // Use multi-step technique: start with original size, then
            // scale down in multiple passes with drawImage()
            // until the target size is reached
            w = img.getWidth();
            h = img.getHeight();
        } else {
            // Use one-step technique: scale directly from original
            // size to target size with a single drawImage() call
            w = targetWidth;
            h = targetHeight;
        }
        
        do {
            if (higherQuality && w > targetWidth) {
                w /= 2;
                if (w < targetWidth) {
                    w = targetWidth;
                }
            }

            if (higherQuality && h > targetHeight) {
                h /= 2;
                if (h < targetHeight) {
                    h = targetHeight;
                }
            }

            BufferedImage tmp = new BufferedImage(w, h, type);
            Graphics2D g2 = tmp.createGraphics();
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, hint);
            g2.drawImage(ret, 0, 0, w, h, null);
            g2.dispose();

            ret = tmp;
        } while (w != targetWidth || h != targetHeight);

        return ret;
    }

}
